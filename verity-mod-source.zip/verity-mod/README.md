# Verity™ (Fabric 1.20.1)
Compilar: sube esta carpeta a GitHub → pestaña Actions → "build" → descarga el artifact `verity-mod` (el .jar).
O en PC con Java 17: `gradle build` → build/libs/verity-1.0.0.jar
Ajustes: boton Config de Mod Menu, tecla J o comando /verityconfig.
