package com.verity.entity;

import com.verity.VerityEntities;
import com.verity.VerityItems;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.listener.ClientPlayPacketListener;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.EntitySpawnS2CPacket;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;

import java.util.UUID;

/**
 * La caja de Verity. Click derecho = empieza la secuencia:
 *  1) animacion: la caja sube (~2 bloques, como un jugador) y se abren las tapas
 *  2) se queda quieta 3 segundos: sale humo del tamano de la caja y asoma la bola
 *  3) se quita el humo, la bola cae, rebota 4 veces y saluda. La caja se desvanece.
 */
public class VerityBoxEntity extends Entity {
    public static final int STATE_IDLE = 0;
    public static final int STATE_RUNNING = 1;

    public static final int RISE_TICKS = 24;    // 1.2 s de animacion de apertura
    public static final int HOVER_TICKS = 60;   // 3 s quieta con humo y la bola asomando
    public static final int CLEAR_TICKS = 10;   // desvanecer
    public static final float HOVER_HEIGHT = 2.0f; // bloques de altura (un jugador mide ~2)

    private static final TrackedData<Integer> STATE =
            DataTracker.registerData(VerityBoxEntity.class, TrackedDataHandlerRegistry.INTEGER);
    private static final TrackedData<Integer> TICKS =
            DataTracker.registerData(VerityBoxEntity.class, TrackedDataHandlerRegistry.INTEGER);

    private UUID owner;
    private UUID ballUuid;
    private boolean ballSpawned;
    private boolean ballReleased;
    private boolean clientBurst;

    public VerityBoxEntity(EntityType<?> type, World world) {
        super(type, world);
    }

    @Override
    protected void initDataTracker() {
        this.dataTracker.startTracking(STATE, STATE_IDLE);
        this.dataTracker.startTracking(TICKS, 0);
    }

    public int getBoxState() {
        return this.dataTracker.get(STATE);
    }

    public int getTicks() {
        return this.dataTracker.get(TICKS);
    }

    private void setTicks(int t) {
        this.dataTracker.set(TICKS, t);
    }

    // ---------- curvas de animacion (las usa tambien el renderer) ----------

    /** Altura (en bloques) a la que esta la caja en el tick t. */
    public static float hoverOffset(float t) {
        float k = MathHelper.clamp(t / RISE_TICKS, 0f, 1f);
        float e = k * k * (3f - 2f * k);
        return HOVER_HEIGHT * e;
    }

    /** 0 = tapas cerradas, 1 = tapas abiertas. */
    public static float lidProgress(float t) {
        float k = MathHelper.clamp((t - 8f) / (RISE_TICKS - 8f), 0f, 1f);
        return k * k * (3f - 2f * k);
    }

    /** Escala de la caja (1 normal, baja a 0 al desvanecerse). */
    public static float fadeScale(float t) {
        float s = t - (RISE_TICKS + HOVER_TICKS);
        if (s <= 0f) return 1f;
        float k = MathHelper.clamp(s / CLEAR_TICKS, 0f, 1f);
        return 1f - k * k;
    }

    // ---------- logica ----------

    @Override
    public void tick() {
        super.tick();
        if (getBoxState() != STATE_RUNNING) return;

        if (getWorld().isClient) {
            clientTick();
            return;
        }

        int t = getTicks() + 1;
        setTicks(t);

        if (t == RISE_TICKS) spawnBall();
        if (ballSpawned && !ballReleased) holdBall(t);
        if (t >= RISE_TICKS + HOVER_TICKS && !ballReleased) releaseBall();
        if (t >= RISE_TICKS + HOVER_TICKS + CLEAR_TICKS) discard();
    }

    private void clientTick() {
        int t = getTicks();
        if (t >= RISE_TICKS && t < RISE_TICKS + HOVER_TICKS) {
            double baseY = getY() + HOVER_HEIGHT;
            for (int i = 0; i < 3; i++) {
                double px = getX() + (this.random.nextDouble() - 0.5) * 1.2;
                double pz = getZ() + (this.random.nextDouble() - 0.5) * 0.9;
                double py = baseY + this.random.nextDouble() * 0.8;
                getWorld().addParticle(ParticleTypes.LARGE_SMOKE, px, py, pz, 0.0, 0.02, 0.0);
                getWorld().addParticle(ParticleTypes.SMOKE, px, py, pz,
                        (this.random.nextDouble() - 0.5) * 0.02, 0.03, (this.random.nextDouble() - 0.5) * 0.02);
            }
        }
        if (t >= RISE_TICKS + HOVER_TICKS && !clientBurst) {
            clientBurst = true;
            double baseY = getY() + HOVER_HEIGHT;
            for (int i = 0; i < 18; i++) {
                getWorld().addParticle(ParticleTypes.POOF,
                        getX() + (this.random.nextDouble() - 0.5) * 1.2,
                        baseY + this.random.nextDouble() * 0.8,
                        getZ() + (this.random.nextDouble() - 0.5) * 0.9,
                        0.0, 0.03, 0.0);
            }
        }
    }

    private void start(PlayerEntity player) {
        this.owner = player.getUuid();
        this.dataTracker.set(STATE, STATE_RUNNING);
        setTicks(0);
        getWorld().playSound(null, getX(), getY(), getZ(), SoundEvents.BLOCK_CHEST_OPEN, SoundCategory.NEUTRAL, 1.0f, 1.2f);
    }

    private void spawnBall() {
        VerityBallEntity ball = VerityEntities.BALL.create(getWorld());
        if (ball == null) return;
        ball.refreshPositionAndAngles(getX(), getY() + HOVER_HEIGHT + 0.1, getZ(), 0f, 0f);
        ball.setOwnerUuid(this.owner);
        ball.configureFromBox();
        getWorld().spawnEntity(ball);
        this.ballUuid = ball.getUuid();
        this.ballSpawned = true;
        getWorld().playSound(null, getX(), getY() + HOVER_HEIGHT, getZ(),
                SoundEvents.ENTITY_ILLUSIONER_MIRROR_MOVE, SoundCategory.NEUTRAL, 1.0f, 1.3f);
    }

    private VerityBallEntity findBall() {
        if (this.ballUuid == null || !(getWorld() instanceof ServerWorld sw)) return null;
        Entity e = sw.getEntity(this.ballUuid);
        return e instanceof VerityBallEntity b ? b : null;
    }

    private void holdBall(int t) {
        VerityBallEntity ball = findBall();
        if (ball == null || ball.getBallState() != VerityBallEntity.STATE_HELD) return;
        float k = MathHelper.clamp((t - RISE_TICKS) / 16f, 0f, 1f);
        float e = k * k * (3f - 2f * k);
        ball.setPosition(getX(), getY() + hoverOffset(t) + 0.1 + 0.5 * e, getZ());
    }

    private void releaseBall() {
        this.ballReleased = true;
        VerityBallEntity ball = findBall();
        if (ball != null) ball.release();
        if (getWorld() instanceof ServerWorld sw) {
            sw.spawnParticles(ParticleTypes.POOF, getX(), getY() + HOVER_HEIGHT + 0.4, getZ(), 12, 0.5, 0.3, 0.4, 0.02);
        }
        getWorld().playSound(null, getX(), getY() + HOVER_HEIGHT, getZ(),
                SoundEvents.BLOCK_WOOL_BREAK, SoundCategory.NEUTRAL, 1.0f, 0.8f);
    }

    // ---------- interaccion ----------

    @Override
    public ActionResult interact(PlayerEntity player, Hand hand) {
        if (getBoxState() == STATE_IDLE) {
            if (player.isSneaking()) {
                if (!getWorld().isClient) {
                    player.getInventory().offerOrDrop(new ItemStack(VerityItems.BOX));
                    discard();
                }
                return ActionResult.success(getWorld().isClient);
            }
            if (!getWorld().isClient) start(player);
            return ActionResult.success(getWorld().isClient);
        }
        return ActionResult.PASS;
    }

    @Override
    public boolean canHit() {
        return !isRemoved();
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public boolean isCollidable() {
        return false;
    }

    @Override
    public boolean damage(DamageSource source, float amount) {
        if (!getWorld().isClient && source.getAttacker() instanceof PlayerEntity p && p.isCreative()) {
            discard();
        }
        return false;
    }

    @Override
    public ItemStack getPickBlockStack() {
        return new ItemStack(VerityItems.BOX);
    }

    @Override
    protected void readCustomDataFromNbt(NbtCompound nbt) {
        this.dataTracker.set(STATE, nbt.getInt("BoxState"));
        this.dataTracker.set(TICKS, nbt.getInt("BoxTicks"));
        if (nbt.containsUuid("Owner")) this.owner = nbt.getUuid("Owner");
        if (nbt.containsUuid("Ball")) this.ballUuid = nbt.getUuid("Ball");
        this.ballSpawned = nbt.getBoolean("BallSpawned");
        this.ballReleased = nbt.getBoolean("BallReleased");
    }

    @Override
    protected void writeCustomDataToNbt(NbtCompound nbt) {
        nbt.putInt("BoxState", getBoxState());
        nbt.putInt("BoxTicks", getTicks());
        if (this.owner != null) nbt.putUuid("Owner", this.owner);
        if (this.ballUuid != null) nbt.putUuid("Ball", this.ballUuid);
        nbt.putBoolean("BallSpawned", this.ballSpawned);
        nbt.putBoolean("BallReleased", this.ballReleased);
    }

    @Override
    public Packet<ClientPlayPacketListener> createSpawnPacket() {
        return new EntitySpawnS2CPacket(this);
    }
}
