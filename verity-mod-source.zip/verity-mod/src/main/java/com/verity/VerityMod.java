package com.verity;

import net.fabricmc.api.ModInitializer;
import net.minecraft.util.Identifier;

public class VerityMod implements ModInitializer {
    public static final String MODID = "verity";

    public static Identifier id(String path) {
        return new Identifier(MODID, path);
    }

    @Override
    public void onInitialize() {
        VerityEntities.register();
        VerityItems.register();
        VerityCommands.register();
    }
}
