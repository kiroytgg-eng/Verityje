package com.verity;

import com.mojang.brigadier.context.CommandContext;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

public class VerityCommands {
    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                dispatcher.register(CommandManager.literal("verity")
                        .executes(ctx -> give(ctx, VerityItems.BOX))
                        .then(CommandManager.literal("box").executes(ctx -> give(ctx, VerityItems.BOX)))
                        .then(CommandManager.literal("ball").executes(ctx -> give(ctx, VerityItems.BALL)))));
    }

    private static int give(CommandContext<ServerCommandSource> ctx, Item item) {
        try {
            ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
            player.getInventory().offerOrDrop(new ItemStack(item));
            ctx.getSource().sendFeedback(() -> Text.literal("Verity: te di " + item.getName().getString() + ". Ajustes: tecla J o /verityconfig"), false);
            return 1;
        } catch (Exception e) {
            return 0;
        }
    }
}
