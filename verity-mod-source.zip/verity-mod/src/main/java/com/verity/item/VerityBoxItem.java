package com.verity.item;

import com.verity.VerityEntities;
import com.verity.entity.VerityBoxEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class VerityBoxItem extends Item {
    public VerityBoxItem(Settings settings) {
        super(settings);
    }

    /** Click derecho (en el aire o en un bloque): la caja aparece 3 bloques frente a ti, en el suelo. */
    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        ItemStack stack = player.getStackInHand(hand);
        if (!world.isClient) {
            Vec3d look = player.getRotationVector();
            double lx = look.x, lz = look.z;
            double len = Math.sqrt(lx * lx + lz * lz);
            if (len < 1.0E-4) {
                lx = 0;
                lz = 1;
                len = 1;
            }
            double x = player.getX() + lx / len * 3.0;
            double z = player.getZ() + lz / len * 3.0;
            double y = player.getY();
            int fy = MathHelper.floor(player.getY());
            for (int dy = 3; dy >= -5; dy--) {
                BlockPos bp = new BlockPos(MathHelper.floor(x), fy + dy, MathHelper.floor(z));
                var shape = world.getBlockState(bp).getCollisionShape(world, bp);
                if (!shape.isEmpty() && world.getBlockState(bp.up()).getCollisionShape(world, bp.up()).isEmpty()) {
                    y = bp.getY() + shape.getMax(Direction.Axis.Y);
                    break;
                }
            }
            VerityBoxEntity box = VerityEntities.BOX.create(world);
            if (box == null) return TypedActionResult.fail(stack);
            box.refreshPositionAndAngles(x, y, z, player.getYaw(), 0f);
            world.spawnEntity(box);
            if (!player.isCreative()) stack.decrement(1);
        }
        return TypedActionResult.success(stack, world.isClient);
    }
}
