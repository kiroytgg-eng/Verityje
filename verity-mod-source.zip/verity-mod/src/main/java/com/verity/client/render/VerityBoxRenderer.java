package com.verity.client.render;

import com.verity.entity.VerityBoxEntity;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.Frustum;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.RotationAxis;

public class VerityBoxRenderer extends EntityRenderer<VerityBoxEntity> {
    private static final Identifier TEX = new Identifier("verity", "textures/entity/box.png");

    public VerityBoxRenderer(EntityRendererFactory.Context ctx) {
        super(ctx);
        this.shadowRadius = 0.5f;
    }

    @Override
    public Identifier getTexture(VerityBoxEntity entity) {
        return TEX;
    }

    @Override
    public boolean shouldRender(VerityBoxEntity entity, Frustum frustum, double x, double y, double z) {
        return entity.shouldRender(x, y, z); // la caja sube mucho mas que su hitbox
    }

    @Override
    public void render(VerityBoxEntity entity, float yaw, float tickDelta, MatrixStack m, VertexConsumerProvider vcp, int light) {
        float t = entity.getBoxState() == VerityBoxEntity.STATE_RUNNING ? entity.getTicks() + tickDelta : 0f;
        float hover = VerityBoxEntity.hoverOffset(t);
        float lid = VerityBoxEntity.lidProgress(t);
        float fade = VerityBoxEntity.fadeScale(t);
        if (fade <= 0.001f) return;

        BoxModel model = BoxModel.get();
        VertexConsumer vc = vcp.getBuffer(RenderLayer.getEntityCutoutNoCull(TEX));

        m.push();
        m.translate(0f, hover, 0f);
        m.translate(0f, 0.4f, 0f);
        m.scale(fade, fade, fade);
        m.translate(0f, -0.4f, 0f);
        m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(180f - yaw));
        m.scale(1f / 16f, 1f / 16f, 1f / 16f);

        model.renderGroup("root", m.peek(), vc, light);

        m.push();
        m.translate(0f, 0f, -9.5f * lid);
        m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-20f * lid));
        model.renderGroup("open1", m.peek(), vc, light);
        m.pop();

        m.push();
        m.translate(0f, 0f, 9.5f * lid);
        m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(17.5f * lid));
        model.renderGroup("open2", m.peek(), vc, light);
        m.pop();

        m.pop();
        super.render(entity, yaw, tickDelta, m, vcp, light);
    }
}
