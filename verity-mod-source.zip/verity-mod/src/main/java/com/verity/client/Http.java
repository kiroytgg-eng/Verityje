package com.verity.client;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Map;

/** POST JSON con HttpURLConnection (viene en cualquier Java, tambien en el de Pojav/Android). */
final class Http {
    static final class Response {
        final int code;
        final byte[] body;

        Response(int code, byte[] body) {
            this.code = code;
            this.body = body;
        }

        String text() {
            return new String(body, StandardCharsets.UTF_8);
        }
    }

    static Response postJson(String url, Map<String, String> headers, String json, int readTimeoutMs) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setRequestMethod("POST");
        c.setConnectTimeout(15000);
        c.setReadTimeout(readTimeoutMs);
        c.setDoOutput(true);
        c.setRequestProperty("Content-Type", "application/json");
        for (Map.Entry<String, String> h : headers.entrySet()) {
            c.setRequestProperty(h.getKey(), h.getValue());
        }
        byte[] out = json.getBytes(StandardCharsets.UTF_8);
        c.setFixedLengthStreamingMode(out.length);
        try (OutputStream os = c.getOutputStream()) {
            os.write(out);
        }
        int code = c.getResponseCode();
        InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
        byte[] body = in == null ? new byte[0] : in.readAllBytes();
        if (in != null) in.close();
        c.disconnect();
        return new Response(code, body);
    }

    static String shorten(String s, int max) {
        if (s == null) return "";
        s = s.replaceAll("\\s+", " ").trim();
        return s.length() <= max ? s : s.substring(0, max) + "…";
    }
}
