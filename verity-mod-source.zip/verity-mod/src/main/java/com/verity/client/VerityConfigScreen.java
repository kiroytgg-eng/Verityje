package com.verity.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.function.DoubleConsumer;
import java.util.function.DoubleFunction;

/** Config de Verity (el boton "Config" de Mod Menu). Pestanas: IA, Voz (Fish Audio) y Verity. */
public class VerityConfigScreen extends Screen {
    private final Screen parent;
    private final VerityConfig cfg = VerityConfig.get();
    private int tab = 0;

    private TextFieldWidget geminiKey, geminiModel, groqKey, groqModel, fishKey, fishModel, fishVoice;
    private final List<Object[]> labels = new ArrayList<>(); // {Text, x, y}
    private String info = "";
    private int infoY;

    public VerityConfigScreen(Screen parent) {
        super(Text.literal("Verity™ — Ajustes"));
        this.parent = parent;
    }

    private void collect() {
        if (geminiKey != null) cfg.geminiKey = geminiKey.getText().trim();
        if (geminiModel != null) cfg.geminiModel = geminiModel.getText().trim();
        if (groqKey != null) cfg.groqKey = groqKey.getText().trim();
        if (groqModel != null) cfg.groqModel = groqModel.getText().trim();
        if (fishKey != null) cfg.fishKey = fishKey.getText().trim();
        if (fishModel != null) cfg.fishModel = fishModel.getText().trim();
        if (fishVoice != null) cfg.fishVoiceId = fishVoice.getText().trim();
        geminiKey = geminiModel = groqKey = groqModel = fishKey = fishModel = fishVoice = null;
    }

    private void rebuild() {
        collect();
        this.clearChildren();
        this.init();
    }

    @Override
    protected void init() {
        collect();
        labels.clear();
        int cx = this.width / 2;

        String[] names = {"IA", "Voz (Fish Audio)", "Verity"};
        for (int i = 0; i < names.length; i++) {
            final int idx = i;
            ButtonWidget b = ButtonWidget.builder(Text.literal(names[i]), x -> {
                tab = idx;
                rebuild();
            }).dimensions(cx - 156 + i * 104, 18, 100, 20).build();
            b.active = tab != i;
            addDrawableChild(b);
        }

        int top = 46;
        int spacing = Math.max(17, Math.min(24, (this.height - top - 56) / 6));
        int h = Math.max(14, Math.min(20, spacing - 3));
        int lx = Math.max(6, cx - 170);
        int fx = cx - 50, fw = Math.min(220, this.width - fx - 6);
        int row = 0;

        if (tab == 0) {
            addDrawableChild(ButtonWidget.builder(Text.literal("Proveedor de IA: " + ("groq".equalsIgnoreCase(cfg.provider) ? "Groq" : "Gemini")), b -> {
                cfg.provider = "groq".equalsIgnoreCase(cfg.provider) ? "gemini" : "groq";
                rebuild();
            }).dimensions(lx, top, fx + fw - lx, h).build());
            row++;
            geminiKey = field("Gemini API key", cfg.geminiKey, lx, fx, fw, top + row++ * spacing, h);
            geminiModel = field("Gemini modelo", cfg.geminiModel, lx, fx, fw, top + row++ * spacing, h);
            groqKey = field("Groq API key", cfg.groqKey, lx, fx, fw, top + row++ * spacing, h);
            groqModel = field("Groq modelo", cfg.groqModel, lx, fx, fw, top + row++ * spacing, h);
            info = "Llaves gratis: aistudio.google.com (Gemini) y console.groq.com (Groq)";
            infoY = top + row * spacing + 2;
        } else if (tab == 1) {
            addDrawableChild(ButtonWidget.builder(Text.literal("Voz de Fish Audio: " + (cfg.fishEnabled ? "ACTIVADA" : "apagada")), b -> {
                cfg.fishEnabled = !cfg.fishEnabled;
                rebuild();
            }).dimensions(lx, top, fx + fw - lx, h).build());
            row++;
            fishKey = field("Fish API key", cfg.fishKey, lx, fx, fw, top + row++ * spacing, h);
            fishModel = field("Modelo (s2-pro, s1...)", cfg.fishModel, lx, fx, fw, top + row++ * spacing, h);
            fishVoice = field("ID de voz", cfg.fishVoiceId, lx, fx, fw, top + row++ * spacing, h);
            addDrawableChild(ButtonWidget.builder(Text.literal("Probar voz"), b -> {
                collect();
                VerityConfig.save();
                VerityVoice.say("Hola, soy Verity. Así suena mi voz.");
            }).dimensions(lx, top + row * spacing, fx + fw - lx, h).build());
            row++;
            info = "El ID de voz es el reference_id de la voz en fish.audio (déjalo vacío para la voz por defecto)";
            infoY = top + row * spacing + 2;
        } else {
            addDrawableChild(ButtonWidget.builder(Text.literal("Personalidad: " + cfg.personalityEnum().label), b -> {
                cfg.personality = cfg.personalityEnum().next().name();
                rebuild();
            }).dimensions(lx, top, fx + fw - lx, h).build());
            row++;
            addDrawableChild(new Slider(lx, top + row++ * spacing, fx + fw - lx, h, "Color", 0, 360, cfg.hue,
                    v -> hueName((int) v), v -> cfg.hue = v, true));
            addDrawableChild(new Slider(lx, top + row++ * spacing, fx + fw - lx, h, "Saturación", 0, 1, cfg.saturation,
                    v -> Math.round(v * 100) + "%", v -> cfg.saturation = v, true));
            addDrawableChild(new Slider(lx, top + row++ * spacing, fx + fw - lx, h, "Tamaño", 0.5, 1.8, cfg.size,
                    v -> Math.round(v * 100) + "%", v -> cfg.size = v, false));
            addDrawableChild(new Slider(lx, top + row++ * spacing, fx + fw - lx, h, "Volumen de voz", 0, 1, cfg.volume,
                    v -> Math.round(v * 100) + "%", v -> cfg.volume = v, false));
            addDrawableChild(ButtonWidget.builder(Text.literal("Color original (amarillo)"), b -> {
                cfg.hue = 60;
                cfg.saturation = 1;
                VerityTextures.refresh();
                rebuild();
            }).dimensions(lx, top + row * spacing, fx + fw - lx, h).build());
            row++;
            info = "Habla con ella: tecla V, clic derecho en la bola o escribe «verity …» en el chat";
            infoY = top + row * spacing + 2;
        }

        addDrawableChild(ButtonWidget.builder(Text.literal("Listo"), b -> close())
                .dimensions(cx - 100, this.height - 26, 200, 20).build());
    }

    private TextFieldWidget field(String label, String value, int lx, int fx, int fw, int y, int h) {
        TextFieldWidget f = new TextFieldWidget(this.textRenderer, fx, y, fw, h, Text.literal(label));
        f.setMaxLength(400);
        f.setText(value == null ? "" : value);
        addDrawableChild(f);
        labels.add(new Object[]{Text.literal(label), lx, y + (h - 8) / 2});
        return f;
    }

    private static String hueName(int h) {
        if (h >= 55 && h <= 65) return "Amarillo (original)";
        if (h < 15 || h >= 345) return "Rojo";
        if (h < 40) return "Naranja";
        if (h < 70) return "Amarillo";
        if (h < 160) return "Verde";
        if (h < 200) return "Turquesa";
        if (h < 260) return "Azul";
        if (h < 300) return "Morado";
        return "Rosa";
    }

    @Override
    public void close() {
        collect();
        VerityConfig.save();
        VerityTextures.refresh();
        this.client.setScreen(parent);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        this.renderBackground(ctx);
        ctx.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 5, 0xFFFF55);
        for (Object[] l : labels) {
            ctx.drawTextWithShadow(this.textRenderer, (Text) l[0], (Integer) l[1], (Integer) l[2], 0xE0E0E0);
        }
        ctx.drawCenteredTextWithShadow(this.textRenderer, Text.literal(info), this.width / 2, infoY, 0xAAAAAA);
        super.render(ctx, mouseX, mouseY, delta);
    }

    private static class Slider extends SliderWidget {
        private final String label;
        private final double min, max;
        private final DoubleFunction<String> fmt;
        private final DoubleConsumer setter;
        private final boolean refreshOnRelease;

        Slider(int x, int y, int w, int h, String label, double min, double max, double value,
               DoubleFunction<String> fmt, DoubleConsumer setter, boolean refreshOnRelease) {
            super(x, y, w, h, Text.empty(), (Math.max(min, Math.min(max, value)) - min) / (max - min));
            this.label = label;
            this.min = min;
            this.max = max;
            this.fmt = fmt;
            this.setter = setter;
            this.refreshOnRelease = refreshOnRelease;
            updateMessage();
        }

        @Override
        protected void updateMessage() {
            setMessage(Text.literal(label + ": " + fmt.apply(min + this.value * (max - min))));
        }

        @Override
        protected void applyValue() {
            setter.accept(min + this.value * (max - min));
        }

        @Override
        public void onRelease(double mouseX, double mouseY) {
            super.onRelease(mouseX, mouseY);
            if (refreshOnRelease) VerityTextures.refresh();
        }
    }
}
