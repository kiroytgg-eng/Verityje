package com.verity.client;

import com.google.gson.JsonObject;
import net.minecraft.client.MinecraftClient;
import net.minecraft.sound.SoundCategory;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.lwjgl.BufferUtils;
import org.lwjgl.openal.AL10;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Verity habla: escribe en el chat (en amarillo) y a la misma vez reproduce la voz de Fish Audio.
 * El audio se pide como WAV y se reproduce con el OpenAL del propio Minecraft (funciona tambien en Pojav/Android).
 */
public final class VerityVoice {
    private static final ExecutorService POOL = Executors.newCachedThreadPool(r -> {
        Thread t = new Thread(r, "Verity-Voice");
        t.setDaemon(true);
        return t;
    });

    private static volatile boolean speaking;
    private static int fallbackTicks;
    private static int alSource;
    private static int alBuffer;

    private VerityVoice() {
    }

    /** True mientras Verity esta hablando (lo lee el renderer para estirar la bola y poner la cara de hablar). */
    public static boolean isSpeaking() {
        return speaking;
    }

    /** Verity dice algo: chat + voz. Llamar desde el hilo del cliente. */
    public static void say(String text) {
        MinecraftClient mc = MinecraftClient.getInstance();
        VerityConfig cfg = VerityConfig.get();
        String clean = cleanForSpeech(text);
        if (cfg.fishEnabled && cfg.fishKey != null && !cfg.fishKey.isBlank() && !clean.isEmpty()) {
            final String key = cfg.fishKey.trim();
            final String model = cfg.fishModel == null || cfg.fishModel.isBlank() ? "s2-pro" : cfg.fishModel.trim();
            final String voice = cfg.fishVoiceId == null ? "" : cfg.fishVoiceId.trim();
            POOL.execute(() -> {
                try {
                    Wav wav = Wav.parse(fishTts(key, model, voice, clean));
                    mc.execute(() -> {
                        showChat(text);
                        play(wav, text);
                    });
                } catch (Exception e) {
                    mc.execute(() -> {
                        showChat(text);
                        mc.inGameHud.getChatHud().addMessage(Text.literal("[Verity] Fish Audio: "
                                + Http.shorten(String.valueOf(e.getMessage()), 200)).formatted(Formatting.RED));
                        startFallback(text);
                    });
                }
            });
        } else {
            showChat(text);
            startFallback(text);
        }
    }

    /** Llamar una vez por tick del cliente. */
    public static void tick() {
        if (alSource != 0) {
            boolean playing;
            try {
                playing = AL10.alGetSourcei(alSource, AL10.AL_SOURCE_STATE) == AL10.AL_PLAYING;
            } catch (Throwable t) {
                playing = false;
            }
            if (!playing) {
                releaseAudio();
                speaking = false;
            }
        } else if (fallbackTicks > 0) {
            fallbackTicks--;
            if (fallbackTicks == 0) speaking = false;
        }
    }

    public static void stop() {
        releaseAudio();
        fallbackTicks = 0;
        speaking = false;
    }

    // ------------------------------------------------------------------ chat

    private static void showChat(String text) {
        MutableText line = Text.literal("<Verity> " + text).formatted(Formatting.YELLOW);
        MinecraftClient.getInstance().inGameHud.getChatHud().addMessage(line);
    }

    private static void startFallback(String text) {
        releaseAudio();
        fallbackTicks = Math.max(40, Math.min(260, (int) (text.length() * 2.4)));
        speaking = true;
    }

    // ---------------------------------------------------------------- Fish

    private static byte[] fishTts(String key, String model, String voice, String text) throws IOException {
        JsonObject body = new JsonObject();
        body.addProperty("text", text);
        if (!voice.isEmpty()) body.addProperty("reference_id", voice);
        body.addProperty("format", "wav");
        body.addProperty("sample_rate", 44100);
        Map<String, String> headers = new HashMap<>();
        headers.put("Authorization", "Bearer " + key);
        headers.put("model", model);
        Http.Response r = Http.postJson("https://api.fish.audio/v1/tts", headers, body.toString(), 60000);
        if (r.code >= 400) throw new IOException("HTTP " + r.code + " " + Http.shorten(r.text(), 180));
        return r.body;
    }

    private static String cleanForSpeech(String s) {
        return s.replaceAll("https?://\\S+", "").replaceAll("[*_`#]", "").replaceAll("\\s+", " ").trim();
    }

    // ---------------------------------------------------------------- audio

    private static void play(Wav wav, String text) {
        releaseAudio();
        try {
            MinecraftClient mc = MinecraftClient.getInstance();
            ByteBuffer bb = BufferUtils.createByteBuffer(wav.pcm.length);
            bb.put(wav.pcm).flip();
            int buffer = AL10.alGenBuffers();
            AL10.alBufferData(buffer, wav.channels == 1 ? AL10.AL_FORMAT_MONO16 : AL10.AL_FORMAT_STEREO16, bb, wav.sampleRate);
            int source = AL10.alGenSources();
            float gain = (float) VerityConfig.get().volume
                    * mc.options.getSoundVolume(SoundCategory.MASTER)
                    * mc.options.getSoundVolume(SoundCategory.VOICE);
            AL10.alSourcei(source, AL10.AL_BUFFER, buffer);
            AL10.alSourcei(source, AL10.AL_SOURCE_RELATIVE, AL10.AL_TRUE);
            AL10.alSource3f(source, AL10.AL_POSITION, 0f, 0f, 0f);
            AL10.alSourcef(source, AL10.AL_GAIN, Math.max(0f, Math.min(1f, gain)));
            AL10.alSourcePlay(source);
            int err = AL10.alGetError();
            if (err != AL10.AL_NO_ERROR) {
                AL10.alDeleteSources(source);
                AL10.alDeleteBuffers(buffer);
                throw new IllegalStateException("OpenAL error " + err);
            }
            alSource = source;
            alBuffer = buffer;
            fallbackTicks = 0;
            speaking = true;
        } catch (Throwable t) {
            alSource = 0;
            alBuffer = 0;
            MinecraftClient.getInstance().inGameHud.getChatHud().addMessage(
                    Text.literal("[Verity] No pude reproducir el audio: " + t).formatted(Formatting.RED));
            startFallback(text);
        }
    }

    private static void releaseAudio() {
        try {
            if (alSource != 0) {
                AL10.alSourceStop(alSource);
                AL10.alDeleteSources(alSource);
            }
            if (alBuffer != 0) AL10.alDeleteBuffers(alBuffer);
        } catch (Throwable ignored) {
        }
        alSource = 0;
        alBuffer = 0;
    }

    /** Un WAV PCM de 16 bits ya desempaquetado. */
    static final class Wav {
        final byte[] pcm;
        final int channels;
        final int sampleRate;

        Wav(byte[] pcm, int channels, int sampleRate) {
            this.pcm = pcm;
            this.channels = channels;
            this.sampleRate = sampleRate;
        }

        static Wav parse(byte[] d) throws IOException {
            if (d.length < 44 || d[0] != 'R' || d[1] != 'I' || d[2] != 'F' || d[3] != 'F') {
                throw new IOException("la respuesta no es WAV: " + Http.shorten(new String(d, 0, Math.min(d.length, 160), StandardCharsets.UTF_8), 120));
            }
            ByteBuffer bb = ByteBuffer.wrap(d).order(ByteOrder.LITTLE_ENDIAN);
            int pos = 12;
            int channels = 1, rate = 44100, bits = 16;
            int dataStart = -1, dataLen = 0;
            while (pos + 8 <= d.length) {
                String id = new String(d, pos, 4, StandardCharsets.US_ASCII);
                long size = bb.getInt(pos + 4) & 0xFFFFFFFFL;
                if (id.equals("fmt ")) {
                    channels = bb.getShort(pos + 10);
                    rate = bb.getInt(pos + 12);
                    bits = bb.getShort(pos + 22);
                } else if (id.equals("data")) {
                    dataStart = pos + 8;
                    dataLen = (int) Math.min(size, (long) d.length - dataStart);
                    break;
                }
                if (size > d.length) break;
                pos += 8 + (int) size + (int) (size & 1);
            }
            if (dataStart < 0) throw new IOException("WAV sin datos de audio");
            if (bits != 16) throw new IOException("WAV de " + bits + " bits no soportado");
            if (channels < 1 || channels > 2) throw new IOException("WAV con " + channels + " canales no soportado");
            dataLen -= dataLen % (2 * channels);
            byte[] pcm = new byte[dataLen];
            System.arraycopy(d, dataStart, pcm, 0, dataLen);
            return new Wav(pcm, channels, rate);
        }
    }
}
